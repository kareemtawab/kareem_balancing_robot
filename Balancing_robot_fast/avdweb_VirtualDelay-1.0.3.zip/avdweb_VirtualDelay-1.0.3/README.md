# VirtualDelay
The standard Arduino delay() function blocks the Arduino, that is not always allowed. The standard delay has limitations too: it is not possible to use multiple delays at the same time. So I decided to developed a non-blocking library which has many advantages.
See the article http://www.avdweb.nl/arduino/libraries/virtualdelay.html
